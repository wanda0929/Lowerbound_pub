# Split knot-headroom certification at 2.93

This directory records an order-6 rational-knot sweep and two exact
certifications for the cumulative-cost split hierarchy
`stationary_torus_hausdorff_split`. All stages ran from the unmodified release
build of commit `45d45bf11abbacd0be693bf0068f78de77d91997` (binary SHA-256
`c7f52fd0b427bf0f6ea48868ff2f8fae6c8f6c22df1e1a7cc4fa04aea3a2ab26`).
No solver, exactifier, auditor, acceptance gate, or golden file was changed.

## Result

The target `293/100` passed both the exactifier's native exact audit and a
separately executed `audit-exact-split --audit-jobs 8` process on two grids:

```text
C* >= 293/100 = 2.93.
```

The primary five-cell grid is `0,1/26,1/3,2/3,25/26,1`; the corroborating
six-cell grid is `0,1/26,1/4,1/2,3/4,25/26,1`. Together with the separate
Arb/Krawczyk upper witness, the rigorous bracket is

```text
2.93 = 293/100 <= C* < 2.935875225844105,
```

with certified absolute gap less than `0.005875225844105`. In particular, this
establishes the requested rounded bracket `2.93 <= C* < 2.935887` without
discarding the stronger rigorous upper endpoint.

## O6 floating sweep

Every value in this table is a **floating exploration result, not a bound**.
Each solve ran independently under GNU `time -v`. All 22 processes exited 0
with MOSEK status `Optimal` and termination code `100006`. The baseline agrees
with the previous retained value (`2.9316569211448495`). Rows are sorted by
floating objective.

| knots | floating objective | status / term | primal residual | dual residual | wall | peak RSS (KiB) |
|---|---:|---|---:|---:|---:|---:|
| `0,1/26,1/3,2/3,25/26,1` | 2.9321112911587193 | Optimal / 100006 | 1.608696891253203e-7 | 6.778986261224418e-10 | 1:44.46 | 2,848,764 |
| `0,1/26,1/4,1/2,3/4,25/26,1` | 2.9321080097731738 | Optimal / 100006 | 5.501729497581253e-7 | 1.905908486588004e-9 | 1:25.26 | 3,274,416 |
| `0,1/32,1/4,1/2,3/4,31/32,1` | 2.932019350570215 | Optimal / 100006 | 8.449576310133947e-7 | 2.8547955666091696e-9 | 1:24.96 | 3,272,504 |
| `0,1/24,1/8,1/3,2/3,7/8,23/24,1` | 2.9320059132196548 | Optimal / 100006 | 5.313720970925168e-7 | 1.5942580589012323e-9 | 2:21.11 | 3,699,092 |
| `0,1/24,1/3,2/3,25/26,1` | 2.9319793716348386 | Optimal / 100006 | 2.3722721894173238e-7 | 7.314490124699091e-10 | 1:41.68 | 2,758,164 |
| `0,1/24,1/3,2/3,23/24,1` | 2.931855321102944 | Optimal / 100006 | 1.7515808787681858e-7 | 1.4448222618312911e-9 | 1:25.20 | 2,751,804 |
| `0,1/25,1/3,2/3,24/25,1` | 2.9317988298448654 | Optimal / 100006 | 3.1850576724355295e-7 | 1.1068878591480313e-9 | 1:15.38 | 2,746,024 |
| `0,1/27,1/3,2/3,26/27,1` | 2.9317848167302714 | Optimal / 100006 | 9.829026992125376e-7 | 3.752314792215827e-9 | 1:11.15 | 3,054,964 |
| `0,1/24,1/4,1/2,3/4,23/24,1` | 2.931739323043132 | Optimal / 100006 | 2.861726176028867e-7 | 1.6354171350485558e-9 | 1:48.57 | 3,274,012 |
| `0,1/32,1/3,2/3,31/32,1` | 2.9316569211448495 | Optimal / 100006 | 5.114032704672811e-7 | 1.878388611320503e-9 | 1:06.91 | 3,078,112 |
| `0,1/16,1/3,2/3,31/32,1` | 2.9315116784276256 | Optimal / 100006 | 3.3474709357197466e-7 | 1.3782971430842395e-8 | 1:24.99 | 2,747,548 |
| `0,1/22,1/3,2/3,21/22,1` | 2.9314308825454987 | Optimal / 100006 | 3.308091976045313e-7 | 1.5079439918963544e-9 | 1:29.33 | 2,745,496 |
| `0,1/28,1/3,2/3,27/28,1` | 2.931400368241725 | Optimal / 100006 | 1.0641695516477347e-6 | 3.6697013761077812e-9 | 1:04.61 | 3,040,500 |
| `0,1/32,1/3,2/3,15/16,1` | 2.9313903984584613 | Optimal / 100006 | 3.4527681004614154e-7 | 1.1209269068501726e-9 | 1:28.47 | 2,758,076 |
| `0,1/26,1/3,2/3,23/24,1` | 2.9311395975641403 | Optimal / 100006 | 1.4110630030469973e-6 | 4.866640535006184e-9 | 0:59.04 | 2,742,544 |
| `0,1/20,1/3,2/3,19/20,1` | 2.93113495036971 | Optimal / 100006 | 4.731009132230568e-7 | 1.678782335368112e-9 | 1:15.16 | 2,788,652 |
| `0,1/16,1/3,2/3,15/16,1` | 2.930816759193192 | Optimal / 100006 | 1.6658614620569407e-7 | 1.141613414912257e-9 | 1:37.65 | 3,011,872 |
| `0,1/16,1/8,1/3,2/3,7/8,15/16,1` | 2.930646564506617 | Optimal / 100006 | 1.4690351209101227e-6 | 8.21388534966161e-9 | 2:29.61 | 3,943,480 |
| `0,1/16,1/2,15/16,1` | 2.9306334436519137 | Optimal / 100006 | 2.053831748056621e-7 | 3.755982191933072e-9 | 1:13.77 | 2,329,800 |
| `0,1/16,1/4,1/2,3/4,15/16,1` | 2.93054339516317 | Optimal / 100006 | 4.267897950605004e-7 | 2.767321205521256e-9 | 1:45.41 | 3,451,624 |
| `0,1/12,1/3,2/3,11/12,1` | 2.929772587921832 | Optimal / 100006 | 2.7674339253026814e-7 | 9.40221456247059e-10 | 1:30.43 | 2,760,528 |
| `0,1/8,1/3,2/3,7/8,1` | 2.9277363396365104 | Optimal / 100006 | 4.4721703618621437e-7 | 5.6897266897948384e-9 | 1:23.96 | 2,759,356 |

The sweep includes all requested grids plus adaptive shoulder and asymmetric
follow-ups near the best region. The complete result payload, resource record,
and exit status for every row are under `o6-sweep/`.

## Unchanged certification recipe

For each of the top two grids, a fresh reference was generated with
`--dump-solution`, followed by a fixed-target per-block seed:

```bash
target/release/minexposure solve-mosek stationary_torus_hausdorff_split \
  --order 6 --knots GRID --dump-solution \
  --interior-target 293/100 --interior-reference REF \
  --interior-zero-gram-threshold 1e-8 \
  --interior-per-block-margins --interior-margin-cap 1e-3 \
  --output SEED
```

Exactification used the existing segmented checkpoint recipe:

```text
--dyadic-bits 60
--gram-shift-ulps 0
--zero-gram-threshold 1e-8
--cone-margin 5e-6
--cone-margin-cap 1e-4
--cone-gram-scale-target 1e-3
--cone-facial-zero-threshold 1e-7
--cone-correction-bits 52
```

See `run-reference-seed.sh` and `exactify.sh` for the complete invocations and
checkpoint flags.

## Seed and cone diagnostics

The primary five-cell seed maximized average per-block margin to
`0.00014738241714359727`. Of 2,344 requested nonzero Grams, 1,755 had margin
above `1e-8`, 589 had margin at or below `1e-8`, 10 were at/near the cap
(`>=0.000999`), and 362 had margin at least `5e-4`; 321 Grams were inactive.
The margin range was `-1.3294038339754616e-7` to `0.001`. The seed residuals
were `2.752415389634111e-7` primal and `1.0081492474167675e-8` dual.

| primary pass | newly zeroed rows | reconstructed min eig | status / term / iters | primal residual | dual residual | wall | peak RSS (KiB) |
|---:|---:|---:|---|---:|---:|---:|---:|
| 1 | 1,217 | -1.2418058525006808e-7 | UnknownAdvisoryCandidate / 100000 / 30 | 1.7025777162898645e-8 | 0.0025697408527776133 | 1:41.38 | 4,600,068 |
| 2 | 89 | -1.153973789401569e-7 | UnknownAdvisoryCandidate / 100000 / 30 | 1.1452459597262495e-7 | 0.01728546781816931 | 1:20.20 | 5,151,788 |
| 3 | 12 | -2.3685275059288905e-7 | UnknownAdvisoryCandidate / 100000 / 30 | 1.9822875291924946e-7 | 0.029919090653947933 | 1:17.73 | 4,850,736 |
| 4 | 0 | -3.4910957450855897e-15 | Optimal / 0 / 25 | 7.115598899551668e-18 | 2.564161150075961e-8 | 1:45.28 | 5,434,288 |

The corroborating six-cell seed's average margin was
`0.00020469615715253071`. Of 2,818 requested nonzero Grams, 2,093 had margin
above `1e-8`, 725 had margin at or below `1e-8`, 14 were at/near the cap, and
612 had margin at least `5e-4`; 400 Grams were inactive. Its margin range was
`-4.2083293277660707e-8` to `0.001`, and its primal/dual residuals were
`1.3928668352036766e-7` / `3.909404980295683e-9`.

| corroborating pass | newly zeroed rows | reconstructed min eig | status / term / iters | primal residual | dual residual | wall | peak RSS (KiB) |
|---:|---:|---:|---|---:|---:|---:|---:|
| 1 | 1,413 | -3.112323120299242e-8 | UnknownAdvisoryCandidate / 100000 / 30 | 1.1423633060530909e-8 | 0.0017558597573952284 | 2:17.23 | 5,894,008 |
| 2 | 40 | -4.1772994745988684e-8 | UnknownAdvisoryCandidate / 100000 / 30 | 6.619688314971235e-8 | 0.012005432481714706 | 1:31.54 | 6,209,116 |
| 3 | 0 | -3.9178379475325573e-16 | Optimal / 0 / 27 | 1.9469705054918162e-16 | 6.131699592515361e-10 | 2:18.99 | 6,087,800 |

The earlier five-cell O7 2.93 stall on knots
`0,1/32,1/3,2/3,31/32,1` remains a grid-specific historical failure. Neither
O6 trajectory here has that terminal stall signature: both reach zero newly
selected rows and a reconstructed minimum eigenvalue at floating roundoff.

## Exact audit validation

Floating reconstructed eigenvalues are diagnostics, not acceptance criteria.
Both retained certificates passed the exactifier's native exact audit and a
separate independent audit process.

| order | knots | native audit | independent audit | exact identities | PD / zero / residual / exact-LDL Grams | minimum certified eigenvalue lower bound |
|---:|---|---|---|---:|---|---|
| 6 | `0,1/26,1/3,2/3,25/26,1` | PASS, exit 0, 0:52.50, 549,088 KiB | PASS, exit 0, 0:16.93, 304,392 KiB | 9,180; 0 nonzero residuals | 2,086 / 332 / 2,333 / 0 | `444280195169115950363598026645/85070591730234615865843651857942052864` |
| 6 | `0,1/26,1/4,1/2,3/4,25/26,1` | PASS, exit 0, 1:02.22, 652,952 KiB | PASS, exit 0, 0:21.21, 356,880 KiB | 11,048; 0 nonzero residuals | 2,517 / 403 / 2,815 / 0 | `16306274506101417141103451684857/1361129467683753853853498429727072845824` |

Both native and independent reports have `certified_bound: "293/100"`, exact
endpoint bound `293/100`, and
`all_gram_matrices_exactly_positive_semidefinite: true`.

The independent command was executed separately for each certificate:

```bash
target/release/minexposure audit-exact-split CERTIFICATE --audit-jobs 8
```

## Size estimates and stopping decision

Order-7 estimates were retained before choosing whether to escalate:

| O7 grid shape | PSD blocks | largest side | equalities | sum squares | sum cubes | raw PSD bytes |
|---|---:|---:|---:|---:|---:|---:|
| five-cell (baseline or best `1/26`) | 4,226 | 274 | 3,881 | 9,210,439 | 1,572,706,993 | 73,683,512 |
| six-cell | 5,098 | 274 | 4,657 | 11,064,914 | 1,887,718,098 | 88,519,312 |
| seven-cell | 5,970 | 274 | 5,433 | 12,919,389 | 2,202,729,203 | 103,355,112 |

Because O6 already certified the requested target twice, no O7 or O8 floating
solve or exactification was run. No cloud instance was reserved; cloud spend
was `0 CNY`.

## Retained evidence

- `o6-sweep/`: all 22 floating result JSONs, GNU `time -v` records, and exit
  statuses.
- `attempts/o6-shoulder-1-26/` and `attempts/o6-six-cell-1-26/`: reference and
  seed payloads, gzip-compressed exact certificates, exactification logs,
  per-pass diagnostics, stage resources and exit statuses, and both exact audit
  reports.
- `estimates/`: deterministic O7 size estimates.
- `run-o6-sweep.sh`, `run-reference-seed.sh`, and `exactify.sh`: campaign
  drivers.
- `results.json`: machine-readable campaign summary.
- `binary.sha256`, `source-commit.txt`, per-attempt
  `certificate-audits.sha256`, and `SHA256SUMS`: provenance and hashes.

The uncompressed exact certificates exceed the campaign's 95 MiB per-file Git
retention ceiling. Both are retained losslessly as gzip payloads below that
ceiling; `gzip -cd certificate-293.json.gz | sha256sum` verifies the
uncompressed certificate hash.

| grid | raw bytes / SHA-256 | gzip bytes / SHA-256 | audit-report SHA-256 (native and independent) |
|---|---|---|---|
| `0,1/26,1/3,2/3,25/26,1` | 109,403,268 / `907835bf180ec890e7988057b25c308df7109f58f0f64802ac714b694602ddba` | 22,147,531 / `68b8da6707bf602281257e68ce8dc5f30b6ccc5d9be70b56b6913d67624b365b` | `eda531f9fe1d49096880831cf632e92d5e1cc916a392d6dca14be40e7dea8238` |
| `0,1/26,1/4,1/2,3/4,25/26,1` | 128,644,774 / `43057f35f23a8553894c17727c827599544bc32e56ced1ef6b38a7789ae7756c` | 25,696,351 / `d4d3266bda11a9a5ca868fe17f61c068bd1277a12d844228c9009adfc50af48d` | `08d55cd8a764db38ae5c3558146b2c878c8a5d805fab3bdc6eb483b4316f987c` |

The retained primary reference is 32,663,047 bytes (SHA-256
`64f22561a62512e5ac438906c2f265b3f6c4679e6816fb5f40ee65170514c324`)
and its seed is 33,295,857 bytes (SHA-256
`53fc2c630c2ec07dad6ed08f668eba615ccf26fa0c65f95c68ec8fa8abbaae35`).
The corroborating reference is 39,550,026 bytes (SHA-256
`14dde34d1894fdc8555d85c12b9284c9e8499dad159fce63f9d5e5119491c1e5`)
and its seed is 40,169,219 bytes (SHA-256
`784a1784216f1e9e7d1efe4454bc5e8b3b8fd608d4c6bbad9bcb34024ee482f7`).
